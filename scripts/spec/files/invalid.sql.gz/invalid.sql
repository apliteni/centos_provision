CREATE TABLE `keitaro_acl`;
