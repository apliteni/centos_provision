CREATE TABLE `keitaro_acl`;
CREATE TABLE IF NOT EXISTS `schema_version`;
