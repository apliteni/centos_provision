CREATE TABLE `keitaro_clicks`;
CREATE TABLE IF NOT EXISTS `schema_version`;
